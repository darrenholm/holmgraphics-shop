import{j as o}from"./singletons.aa4588bf.js";const e=o("goto");export{e as g};
