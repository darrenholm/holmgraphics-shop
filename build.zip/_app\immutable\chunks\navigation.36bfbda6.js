import{j as o}from"./singletons.ce1d4782.js";const e=o("goto");export{e as g};
